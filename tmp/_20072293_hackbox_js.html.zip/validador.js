/**
 * Imprime error
 * @param {string|number} msg
 */
function mostrarError(msg) {

    let contenedor = document.getElementById('error');

    contenedor.innerHTML = msg;
    contenedor.style.display = 'block';
    contenedor.style.fontWeight = '800';

}

/**
 Validacion del formulario
 */


function validacionFormulario() {
    let arregloErrores = [];

    /** @type {string}*/ let nombre = document.getElementById('nombre').value;

    let regex = /^[a-zA-Z ]*$/;
    if (nombre.length < 10 || nombre.length > 100 || !regex.test(nombre)) {
        arregloErrores.push('Nombre de usuario')

    }

    if(document.getElementById('archivo').files.length ===0 ){

        arregloErrores.push(' Archivo no ingresado');

    }

    /** @type string */ let privacidad = document.getElementById('privacidad').value;
    if(privacidad === ""){

        arregloErrores.push(" Privacidad no puede ser vacio");

    }

    let contrasenasNo = ["password", "1234", "pass", "user", "hackbox"];
    /** @type string */ let contrasena = document.getElementById('password').value;
    if(contrasena !== "" && contrasenasNo.includes(contrasena) && contrasena.length > 10){

        arregloErrores.push(" Contraseña mal ingresada");
    }

    let autodestruccion = document.getElementById('autodestruir').value;
    if(autodestruccion !== "" && (autodestruccion > 3153600 || autodestruccion < 1)){

        arregloErrores.push(" Autodestruccion mal ingresado");

    }

    /** @type string */ let comentario = document.getElementById('comentario').value;
    if(comentario !== "" && comentario > 1000){

        arregloErrores.push(" Comentario muy largo");

    }

    if(arregloErrores.length !== 0){

        let fraseErrores = "Su formulario falló en: ";
        for(let i = 0; i < arregloErrores.length; i++){

            fraseErrores = fraseErrores + arregloErrores[i] + "," ;
        }
        mostrarError(fraseErrores);
        return false;
    }
    else{

        return true;
    }

    /*
    La idea sería ir añadiendo más validaciones aquí, e ir concatenando el mensaje
    de error si es que existe, para al final realizar "mostrarError(mensaje_error_concatenado)".
     */

    return true;

}

console.log('app v1.0'); // stack trace