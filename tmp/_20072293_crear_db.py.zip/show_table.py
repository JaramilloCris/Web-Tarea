#!C:\Users\groso\AppData\Local\Programs\Python\Python37-32\python.exe

import cgi
import save_data as sd

print("Content-type: text/html\r\n\r\n")


db = sd.PizzaDatabase("root", "")
data = db.get_all('pedido')

head = '''

<!DOCTYPE html>

    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="ejercicio3.css">
        <script src="ejercicio3.js"></script>
        <title>Tabla</title>
    </head>

    <style>
    table, td, th {
    border: 1px solid black;

    }
    
    table {
        border-collapse: collapse;
        width: 100%;
    }
    
    th {
        height: 50px;

    }

    </style>

'''
print(head)
    
html1 = '''
<body>

<h1>Tabla de pizzas ingresadas</h1>

<div id="container">

    <table class = "table-custom">
        <tr>
        <th>Nombre</th>
        <th>Telefono</th>
        <th>Direccion</th>
        <th>Comuna</th>
        <th>Tipo de Masa</th>
        <th>Ingrediente</th>
        <th>Comentario</th>
        </tr>
'''
print(html1)

for d in data:

    row = f'''
            <tr>
                <th>{str(d[1])}</th>
                <th>{str(d[2])}</th>
                <th>{str(d[3])}</th>
                <th>{str(d[4])}</th>
                <th>{str(d[5])}</th>
                <th>{str(d[6])}</th>
                <th>{str(d[7])}</th>
            </tr>
        '''
    print(row)
html2 ='''
</table>

<a href="ejercicio3.html"><button id="myButton2">Inicio</button></a>

</div>

</body>
</html>
'''

print(html2)
