#!C:\Users\groso\AppData\Local\Programs\Python\Python37-32\python.exe

import cgi
import save_data as sd

print("Content-type: text/html\r\n\r\n")

form = cgi.FieldStorage()
db = sd.PizzaDatabase("root", "")


html = f'''

<!DOCTYPE html>

    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="ejercicio3.css">
        <script src="ejercicio3.js"></script>
        <title>Ejercicio 3</title>
    </head>
    
<body>

<h1>Arma tu Pizza!</h1>

<div id="container">

    Tus datos han sido ingresados correctamente!
  
</div>
<a href="ejercicio3.html"><button id="myButton3">Inicio</button></a>

</body>
</html>

'''

print(html)

data = (

    form["nombre"].value, form["telefono"].value, \
        form["direccion"].value, form["comuna"].value, \
            form["masa"].value, form["ingrediente"].value, form["comentario"].value,
)

db.save_data(data)